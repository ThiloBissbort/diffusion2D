%This script can be used to set up a 2-D concentration grid (e.g. zoned
%crystal) and to study c-dependent & anisotropic diffusion.



%% INPUT
%dx and dy = 1 for now

function [x,y,C_ini,C_new,C,x_dist,x_profile_ini_C,x_profile_C,y_dist,y_profile_ini_C,y_profile_C,y_profile_x,y_profile_y,x_profile_x,x_profile_y] = twodimensionalD(Dx,Dy,time,dx,dy,x_length,y_length,xi1,xi2,int2activate,c_core,c_rim1,c_rim2,pos_x_profile,pos_y_profile)


% Dx = 1;
% Dy = 1;
% time = 10;
% dx = 0.5;
% dy = 0.5;
% x_length = 50;
% y_length = 80;

r = 0.4;
dt = r*dx^2/max(Dx,Dy);
timesteps = int32(time/dt);
x = (1:1:x_length);
y = (1:1:y_length);


x_nodes = x_length/dx;
y_nodes = y_length/dy;


x(1) = 0;
y(1) = 0;
for i = 2:x_nodes
    x(i) = x(i-1)+dx;
end
for k = 2:y_nodes
    y(k) = y(k-1)+dy;
end

%% INITIAL C-MATRIX


% this routine is used to set up the initial concentration distribution in
% the crystal using multiple zones. One quarter (C1, upper-left) of the crystal is filled
% with concentrations at each node. This is then flipped to C2
% (upper-right), C3 (lower-left), and C4 (lower-right) and put into one
% c-matrix C.

C1 = zeros(y_length/2,x_length/2);

% core concentration
for k = 1:y_nodes/2
    for i = 1:x_nodes/2
        C1(k,i) = c_core;
    end
end

%rim1
for k = 1:y_nodes/2 
    for i = 1:xi1
        C1(k,i) = c_rim1;
    end
end
for k = 1:xi1
    for i = 1:x_nodes/2
        C1(k,i) = c_rim1;
    end
end

%rim2
if int2activate == 1
    for k = xi1+1:y_nodes/2 
        for i = xi1+1:xi2
            C1(k,i) = c_rim2;
        end
    end
    for k = xi1:xi2
        for i = xi1+1:x_nodes/2
            C1(k,i) = c_rim2;
        end
    end 
elseif int2activate == 0
end

C2 = fliplr(C1);
C4 = flipud(C2);
C3 = fliplr(C4);
C = zeros(y_nodes,x_nodes);
C(1:y_nodes/2,1:x_nodes/2) = C1;
C(1:y_nodes/2,x_nodes/2+1:x_nodes) = C2;
C(y_nodes/2+1:y_nodes,1:x_nodes/2) = C3;
C(y_nodes/2+1:y_nodes,x_nodes/2+1:x_nodes) = C4;

%---alternative method to set up initial crystal---------------------------
%--------------------------------------------------------------------------

% for k = 1:y_nodes/2
%     for i = 1:x_nodes/2   
%         if k <= xi1 || i <= xi1
%             p1 = 0.1;
%             C(k,i) = p1;
%         elseif k > xi1 && k <= xi2 || i > xi1 && i <= xi2
%             p2 = 0.5;
%             C(k,i) = p2;
%         else
%             p3 = 0.3;
%             C(k,i) = p3;
%         end
%     end
% end
% C2 = fliplr(C1);
% C4 = flipud(C2);
% C3 = fliplr(C4);
% C = zeros(y_nodes,x_nodes);
% C(1:y_nodes/2,1:x_nodes/2) = C1;
% C(1:y_nodes/2,x_nodes/2+1:x_nodes) = C2;
% C(y_nodes/2+1:y_nodes,1:x_nodes/2) = C3;
% C(y_nodes/2+1:y_nodes,x_nodes/2+1:x_nodes) = C4;

%--------------------------------------------------------

% for one zoned/diffused crystal
% C_rim = 0.1;
% for k = 1:y_nodes/2
%     for i = 1:x_nodes/2       
%             p1 = log(i*k)*C_rim;
%             C(k,i) = p1;
%     end
% end
% C1 = C;
% C2 = fliplr(C1);
% C4 = flipud(C2);
% C3 = fliplr(C4);
% C(1:y_nodes/2,x_nodes/2+1:x_nodes) = C2;
% C(y_nodes/2+1:y_nodes,1:x_nodes/2) = C3;
% C(y_nodes/2+1:y_nodes,x_nodes/2+1:x_nodes) = C4;
% C(1,:) = 0;
% C(end,:) = 0;
% C(:,1) = 0;
% C(:,end) = 0;
% C(20:30,20:30) = 1.0;



%% INITIAL D-MATRIX
C_ini = C;
DxM(y_nodes,x_nodes) = Dx;
DyM(y_nodes,x_nodes) = Dy;

%% FINITE DIFFERENCE
DxM(:,:) = Dx; %.*C_ini; %linear c-dependence of D along x
DyM(:,:) = Dy;% .*C_ini; %linear c-dependence of D along x
C_new = C_ini;
C_old = C_new;

for j = 1:timesteps
    DxM = DxM; %new D-matrix using last concentrations
    DyM = DyM; %new D-matrix using last concentrations
    C_old = C_new;
    for k = 2:y_nodes-1
        for i = 2:x_nodes-1
            C_new(k,i) = C_old(k,i)+(DxM(k,i)*dt/dx)*(C_old(k,i+1)-2*C_old(k,i)+C_old(k,i-1))+(DyM(k,i)*dt/dy)*(C_old(k+1,i)-2*C_old(k,i)+C_old(k-1,i));
        end
    end
end

%% 1-D PROFILE

%--profile along y initial
y_profile_x_index = pos_y_profile/dy;
y_profile_x = y_profile_x_index;
y_profile_ini_C = C_ini(:,y_profile_x_index);
y_profile_x(1:y_nodes) = y_profile_x;
y_profile_y = y;
y_dist = y_profile_y;

%---profile along y after diffusion

y_profile_C = C_new(:,y_profile_x_index);


%---profile along x after diffusion
x_profile_y_index = pos_x_profile/dx;
x_profile_y = x_profile_y_index;
x_profile_ini_C = C(x_profile_y_index,:);
x_profile_y(1:x_nodes) = x_profile_y;
x_profile_x = x;
x_dist = x_profile_x;

x_profile_C = C_new(x_profile_y_index,:);



%% PLOTTING

% dist_max = max(x_length,y_length);
% color_min = min(min(min(C_ini)),min(min(C)));
% color_max = max(max(max(C_ini)),max(max(C)));
% 
% 
% %INITIAL 
% colormap(jet)
% figure(1)
% subplot(2,2,1)
% imagesc(x,y,C_ini)
% x_upper = x_length+dist_max/2/10;
% x_bottom = (-dist_max/2)/10;
% y_upper = y_length+dist_max/2/10;
% y_bottom = (-dist_max/2)/10;
% xlim([x_bottom x_upper]);
% ylim([y_bottom y_upper]);
% xlabel('x distance');
% ylabel('y distance');
% daspect([1 1 1])
% a = colorbar;
% ylabel(colorbar,'concentration')
% caxis([color_min color_max])
% hold on;
% line(y_profile_x,y_profile_y,'LineWidth',2,'Color','k')
% title('Initial')
% 
% %AFTER DIFFUSION
% subplot(2,2,2)
% imagesc(x,y,C_new)
% x_upper = x_length+dist_max/2/10;
% x_bottom = (-dist_max/2)/10;
% y_upper = y_length+dist_max/2/10;
% y_bottom = (-dist_max/2)/10;
% xlim([x_bottom x_upper]);
% ylim([y_bottom y_upper]);
% xlabel('x distance');
% ylabel('y distance');
% daspect([1 1 1])
% a = colorbar;
% ylabel(colorbar,'concentration')
% caxis([color_min color_max])
% hold on;
% line(y_profile_x,y_profile_y,'LineWidth',2,'Color','k')
% hold on;
% line(x_profile_x,x_profile_y,'LineWidth',2,'Color','w')
% title('Diffused')
% 
% %PROFILE ALONG X
% subplot(2,2,3)
% plot(x_dist,x_profile_ini_C,'LineWidth',1.5)
% hold on;
% plot(x_dist,x_profile_C,'LineWidth',1.5)
% legend('initial','diffused')
% ylim([0 max(max(C))+max(max(C))/10])
% xlim([0 x_length])
% xlabel('distance')
% ylabel('concentration')
% title('x profile')
% 
% %PROFILE ALONG Y
% subplot(2,2,4)
% plot(y_dist,y_profile_ini_C,'LineWidth',1.5)
% hold on;
% plot(y_dist,y_profile_C,'LineWidth',1.5)
% legend('initial','diffused')
% ylim([0 max(max(C))+max(max(C))/10])
% xlabel('distance')
% ylabel('concentration')
% title('y profile')


% figure(3)
% surf(xy(1,:),xy(2,:),C)
% x_top = max(x)+100;
% x_bottom = min(x)-100;
% y_top = max(y)+100;
% y_bottom = min(y)-100;
% z_top = max(C,[],'all')+10;
% z_bottom = min(C,[],'all')-10;
% xlim([x_bottom x_top])
% ylim([y_bottom y_top])
% zlim([z_bottom z_top])
end
